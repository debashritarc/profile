﻿<?php
include('header.php')
?>
<title>Contact Us<< CMEA-2018</title>
	<?php
	include('sidebar.php')
	?>
             <?php
             include('slider.php')
             ?>
			
			<div id="maincontent">
				<h1>Contact Us</h1>
				<div >
					
						<p align="justify">
						<font size="3" color="#333366"><b>Dr. Himanshu Pathak </b><br />
												Course Coordinator, <br />
												School of Engineering, <br />
Indian Institute of Technology Mandi<br />
Kamand – 175075, Mandi, Himachal Pradesh<br />
Contact: +91-1905-267267224(O)<br />

Email: stciitmandi@gmail.com <br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; <br />
</font>
						</p>

					
			</div>
					
			</div>
			
			
		
			

</div><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><div id="globalnav">
			<ul>
				
<li><br /></li>
		
			</ul>
		</div>

</body></html>
