<?php
include('header.php')
?>
<title>Resource Person << CMEA-2018</title>
	<?php
	include('sidebar.php')
	?>
             <?php
             include('slider.php')
             ?>
				
			<div id="maincontent">
				<h1>Committees</h1>
				<div>

						<p id="para1"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Patron </b><br />
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prof. T. A. Gonsalves, <br />
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Director,  IIT Mandi<br /><br />

							<b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Advisory Committee</b><br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prof. S.C. Jain, IIT Mandi  <br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prof. Subrata Ray, IIT Mandi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prof. Ramesh Oruganti, IIT Mandi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prof. B. D. Chaudhary, IIT Delhi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prof. . S.R. Kale, IIT Delhi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prof. Deepak Khemani, IIT Mandi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Prem Felix Siril, IIT Mandi<br />
						
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Pradeep Parameswaran, IIT Mandi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Suman Kalyanpal, IIT Mandi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Subrata Ghosh, IIT Mandi
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Rahul Vaish, IIT Mandi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Bharat Singh Rajpurohit, IIT Mandi<br />
								
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dr. Manoj Thakur, IIT Mandi<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Rajeev Kumar, IIT Mandi<br /><br />


								<b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organizing committee </b><br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dr. Vishal S Chauhan, IIT Mandi <br />
								
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. P. Anil Kishan, IIT Mandi  <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Sudhir Kumar Pandey, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Pradeep Kumar, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Mohammad Talha, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Jaspreet Kaur Randhawa, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Viswanath Balakrishnan, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Atul Dhar, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Arpan Gupta, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Rajesh Ghosh, IIT Mandi <br />
								
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Satvasheel Powar, IIT Mandi <br />
								
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Sunny Zafar, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Himanshu Pathak, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Sumit Sinha Ray, IIT Mandi <br />
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dr. Gaurav Bhutani, IIT Mandi <br />

						</p>
						

				</div>
			</div>
	</body>
</html>
