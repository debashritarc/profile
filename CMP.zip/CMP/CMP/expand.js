$(document).ready(function(){
	$('.abstract h3').css({'background':'#fff','cursor':'pointer','padding-left':'10px'});
	$('.abstract .data').hide();
	$('<span class="expand"> &nbsp;&nbsp;</span><span class="collapse"> &nbsp;&nbsp;&nbsp;</span>').prependTo('.abstract h3');
	$('<span class="expand1"> &nbsp;&nbsp;&nbsp;</span><span class="collapse1">&nbsp;&nbsp;&nbsp;</span>').appendTo('.abstract h3');
	$('.collapse , .collapse1').hide();
	$('.expand , .collapse').css({'font-size':'14px','font-weight':'bold','color':'#000'});
	$('.expand1 , .collapse1').css({'font-size':'12px','font-weight':'normal','color':'#000'});
	
	$('.abstract h3').click(function(){
		var text = $(this).parent().find('.data');
		if(text.is(':visible')){
			$(this).css({'background':'#fff'});
			text.slideUp('fast');
			$(this).find('.collapse, .collapse1').hide();
			$(this).find('.expand , .expand1').show();
		}
		else{
			$(this).css({'background':'#c3d9ff'});
			text.slideDown();
			$(this).find('.collapse , .collapse1').show();
			$(this).find('.expand , .expand1').hide();
		}
	});
});
