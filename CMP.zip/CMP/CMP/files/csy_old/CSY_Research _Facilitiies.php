<?php
include "header.php";

?>

<!-- places -->
<div class="partners  widget-content" id="scope">
	<div class="row">
		<div class="">
			<div class="center-content">
				<h2 class="">Research Facility</h2>
				<div class="">
					<table style="width:100%; font-size:15px;">
  <tr>
    <td><img style="height:300px;width:375px;max-width: 375px;" src="./files/images/PPMS.jpg" width="50" height="50"></td><td><h5>Physical Properties Measurement System (PPMS)</h5><br>
    <p style="font-size:16px; text-align:justify;">
Electrical transport properties 
DC/AC electrical resistivity, Hall effect, I-V characterization 
T = 1.8 - 600 K    &     H = 0 - 14 T. <br>
Thermal transport properties 
Thermoelectric power, Thermal conductivity, Hall effect, Nernst effect
T = 1.8 - 600 K     &     H = 0 - 14 T 

</p>
 </tr>
<tr>
    <td><img style="height:300px;width:375px;max-width: 375px;" src="./files/images/SQUID.jpg" width="50" height="50"></td><td><h5>SQUID Magnetometer (MPMS)</h5><br>
    <p style="font-size:16px; text-align:justify;">

Magnetic properties
 DC Magnetization (M vs T, M vs H), AC susceptibility  
T = 1.8 - 400 K,  H = 0 - 7 T


</p>
  </tr>

<tr>
    <td><img style="height:300px;width:375px;max-width: 375px;" src="./files/images/ThreeZonefurnace.png" width="50" height="50"></td><td><h5>Three Zone Furnace</h5><br>
    <p style="font-size:16px; text-align:justify;">
Separately controlled three zones(Nabertherm), Max. temp 1300C, Single crystal growth, Chemical vapor transport 

</p>
  </tr>

<tr>
    <td><img style="height:300px;width:300px;max-width: 300px;" src="./files/images/Tubefurnace.png" width="50" height="50"></td><td><h5>Tube Furnace</h5><br>
	<p style="font-size:16px; text-align:justify;">
	 Tube Furnace (Carbolite Inc), Max. temp 1400 C
</p>
  </tr>
<tr>
    <td><img style="height:300px;width:375px;max-width: 375px;" src="./files/images/Mufflefurnace.png" width="50" height="50"></td><td><h5>Muffle Furnace</h5><br>
	<p style="font-size:16px; text-align:justify;">
	General purpose Box furnace (Thermofisher), Max temp 1100 C, Anealing, Flux growth,etc. 
</p>
  </tr>
 
<br>
<br>
<br>  

</div>
<?php
include "footer.php";

?>