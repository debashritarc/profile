<?php
include "header.php";

?>


<!-- Teaser -->
<div class="C.S.Yadav" id="home">
<div class="banner_bg" data-stellar-background-ratio="0.2" style="background-attachment: fixed;background-image: url(&quot;files/images/banner.gif&quot;); background-position: 50% 0px;"></div>

<div class="row">
		<div class="colums small-12 medium-12-large-12">
			<div class="center-content">
				<!-- Site title -->
				<div class="logo" style="margin-top: 40px">
					<h2 id="site-title", style="color:#FF0000;">Welcome to Shekhar's Homepage </h2>
				</div>
<br><br>
				<!-- Event Info -->
				<div class="event-info" style="margin-top: -2em;">
					<ul class="small-block-grid-1 medium-block-grid-2 ">
											<a href="">
										<img src="./files/images/CSYadav.JPG" width="200px" height="100px">
									</a><li>
							<i class="icon-calendar" style="color: #eb4f25"></i>
							School of Basic Sciences<br>
							Office: A6-9   Lab: A8 Ground Floor<br>
							Indian Institute of Technology Mandi<br>
							Kamand-175075, Mandi (H.P.)<br><br>

							Phone: +91-1905-2672258 <br> Fax: +91-1905-267133
						</li>												
					</ul>
				</div>
<br>
				<!-- Social Links -->
				<div class="row" style=" margin-bottom: -2.5em;    margin-top: -20px">
					<div class="large-6 small-columns">
						<div class="event-social">
							<ul class="small-block-grid-1 medium-block-grid-4 large-block-grid-1">
								<li>
									<a href="">
										<! <img src="files/images/csyadav.jpg" width="300px" height="150px">>
									</a>
								</li>
								</ul>
						</div>
					</div>
				</div>
			 </div>
		   </div>
		 </div>
	  </div>
	
	<div class="row">
		<div class="columns small-12 medium-12 large-12">
			<div class="Left-content"><br><br>
	         	<div class="">
				<b>	<h1 style="text-align: justify; font-size:18px;">I am Faculty member at School of Basic Sciences, Indian Institute of Technology Mandi since May 2013. I did my graduate research work at School of Physical Sciences, Jawaharlal Nehru University New Delhi. For my postdoctoral work, I worked at Tata Institute of Fundamental Research Mumbai, Argonne National Laboratory USA and University of Geneva, Switzerland.</b>
					</div>
				<!-- View all Partners Button Optional -->
			</div>
		</div>
	</div>

<br><br>



<?php
include "footer.php";

?>
