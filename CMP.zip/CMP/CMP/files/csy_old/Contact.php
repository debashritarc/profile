<?php
include "header.php";

?>

<div class="partners  widget-content" id="scope">
	<div class="row">
		<div class="columns small-12 medium-12 large-12">
			<div class="center-content">
			<h2 class="">Contact</h2>
					<h4 style="text-align: justify; font-size:13px;"><ul>
					

					Dr. C.S.Yadav (Shekhar)<br>
					School of Basic Sciences<br>
					Indian Institute of Technology Mandi<br>
					Kamand-175075, Mandi <br>
					HiamchalPradesh India<br>
					<br>
					Email: shekhar@iitmandi.ac.in<br>
					Phone: +91 1905 267258, 267228<br>
					
					

				
						</div>
		</div>
	</div>
</div>















<?php
include "footer.php";

?>