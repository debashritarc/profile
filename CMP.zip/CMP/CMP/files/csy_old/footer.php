<!-- Footer -->
<div class="footer">
	
	<!-- Copyright -->
	<div class="footer_copyright">
		<div class="row">
			<div class="columns small-12 medium-5 large-5">
				© 2017 IIT Mandi WING Team. All Rights Reserved.
			</div>
		</div>
	</div>
</div>
<!-- Google Map Configuration -->

<script src="./files/jss/js"></script>
<script src="./files/jss/vendors.js"></script>
<script src="./files/jss/base.js"></script>	


<script type="text/javascript">(function () {
        return window.SIG_EXT = {};
      })()</script>
  
	  
	  </body></html>
