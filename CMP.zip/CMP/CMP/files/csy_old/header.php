<!DOCTYPE html>
<!--  -->
<html dir="ltr" lang="en-US" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths no-ipad no-iphone no-ipod no-appleios">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">.gm-style-pbc{transition:opacity ease-in-out;background-color:black;text-align:center}.gm-style-pbt{font-size:22px;color:white;font-family:Roboto,Arial,sans-serif;position:relative;margin:0;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)}</style>
<link type="text/css" rel="stylesheet" href="./files/cs/css">
<style type="text/css">.gm-style .gm-style-cc span,.gm-style .gm-style-cc a,.gm-style .gm-style-mtc div{font-size:10px}</style>
<style type="text/css">@media print {  .gm-style .gmnoprint, .gmnoprint {    display:none  }}@media screen {  .gm-style .gmnoscreen, .gmnoscreen {    display:none  }}</style>
<style type="text/css">.gm-style{font-family:Roboto,Arial,sans-serif;font-size:11px;font-weight:400;text-decoration:none}.gm-style img{max-width:none}</style>
	
	<title>Shekhar's webpage</title>
	<meta name="description" content="">
	<meta name="author" content="">

	<!-- Favicon -->
	<link rel="shortcut icon" href="">

	<!-- Mobile Specific Meta -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">

	<!-- CSS -->
	<link type="text/css" rel="stylesheet" href="./files/cs/vendors.css">
	<link type="text/css" rel="stylesheet" href="./files/cs/style.css">
<style type="text/css"></style>
<meta class="foundation-data-attribute-namespace">
<meta class="foundation-mq-xxlarge">
<meta class="foundation-mq-xlarge">
<meta class="foundation-mq-large">
<meta class="foundation-mq-medium">
<meta class="foundation-mq-small">
<style></style>
<script type="text/javascript" charset="UTF-8" src="./files/jss/common.js"></script>
<script type="text/javascript" charset="UTF-8" src="./files/jss/map.js"></script>
<script type="text/javascript" charset="UTF-8" src="./files/jss/util.js"></script>
<script type="text/javascript" charset="UTF-8" src="./files/jss/marker.js"></script>
<script type="text/javascript" charset="UTF-8" src="./files/jss/onion.js"></script>
<script type="text/javascript" charset="UTF-8" src="./files/jss/stats.js"></script>
<script type="text/javascript" charset="UTF-8" src="./files/jss/controls.js"></script>

<link rel="stylesheet" href="./files/cs/owl.carousel.css">
<link rel="stylesheet" href="./files/cs/owl.theme.css">
<link rel="stylesheet" href="./files/cs/location_embedded.css">
<link rel="stylesheet" href="./files/cs/location.css">
<link rel="stylesheet" href="files/cs/animation.css"><!--[if IE 7]><link rel="stylesheet" href="css/location-ie7.css"><![endif]-->
    <script>
      ///function toggleCodes(on) {
        //var obj = document.getElementById('icons');
      
        //if (on) {
         // obj.className += ' codesOn';
        //} else {
        //  obj.className = obj.className.replace(' codesOn', '');
       // }
      //}
      
    </script>
<style>@font-face {
      font-family: 'location';
      src: url('./files/font/location.eot?83938238');
      src: url('./files/font/location.eot?83938238#iefix') format('embedded-opentype'),
           url('./files/font/location.woff?83938238') format('woff'),
           url('./files/font/location.ttf?83938238') format('truetype'),
           url('./files/font/location.svg?83938238#location') format('svg');
      font-weight: normal;
      font-style: normal;
    }
	 .demo-icon
    {
      font-family: "location";
      font-style: normal;
      font-weight: normal;
      speak: none;
     
      display: inline-block;
      text-decoration: inherit;
      width: 1em;
      margin-right: .2em;
      text-align: center;
    }</style>
	
	
	
	
	
	
</head>

<body>
<table width="80%" align="center">
<tr><td>   
<div class="main_menu navbar-fixed">
	<div class="row">
		<div class="columns small-12 medium-12 large-12">
			<div class="mb">
				<div class="navmobile"><a href=""></a></div>
				<ul class="nav-menu">
					<li class="menuItem"><a href="CSY_homepage.php">Home</a></li>
					<li class="menuItem"><a href="CSY_Research_Interest.html">Research Interest</a></li>
					<li class="menuItem"><a href="CSY_Research _Facilitiies.php">Facilities</a></li>
					<li class="menuItem"><a href="CSY Group Members.html">Group Members</a></li>
					<li class="menuItem"><a href="CSY Publications.html">Publications</a></li>
					<li class="menuItem"><a href="CSY teaching.html">Teaching</a></li>
					<li class="menuItem"><a href="CSY_Contact.php">Contact</a></li>
					<li class="menuItem"><a href="">Other</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>