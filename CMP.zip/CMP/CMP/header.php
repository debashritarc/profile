<?php 
//$page= 'index.html';
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="">
<meta name="description" content="">
<link rel="stylesheet" type="text/css" href="style.css" media="screen, print, projection">
<link rel="stylesheet" type="text/css" href="main.css" media="screen, print, projection">
<script type="text/javascript" src="js/jquery_005.js"></script>
<script type="text/javascript" src="js/jquery_002.js"></script>
<script type="text/javascript" src="js/jquery_003.js"></script>
<script type="text/javascript" src="js/jquery_004.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<link rel="SHORTCUT ICON" href="/images/favicon.ico" />
<script type="text/javascript">
$(document).ready(function(){
	$(document).pngFix();
	$("div#actionarea .action_banner").click(function(){window.location=$(this).find("a").attr("href");return false;});
	$.localScroll();
	$("div.tabs").tabs(".slides > div", {effect: 'fade',fadeOutSpeed: "slow",rotate: true}).slideshow({interval: 5000,autoplay: true,clickable: false});
}); //close doc ready
</script>
<style type="text/css">
#para1
{
text-align:justify;
color:black;
} 

ul.bullet{ margin:0; padding:0;}
ul.bullet li{ margin:0; padding:0 0 0 10px; float:left; width:100%; font-weight:normal; line-height:20px; list-style:inside; font-size:12px; font-family:Arial, Helvetica, sans-serif;}

</style>

</head>
<body>
<div id="page">
	 <div id="top_container">
        <div>
            <div id="logo"><a href="http://iitmandi.ac.in/index.html"><img src="images/header.jpg" width="880"></a></div><br /><br />
    </div><br /><br /> <br /><br /><br />
<p align="center" style="background-color:#3498DB"><font color="black" size="2"> 

<br /></font><font color="black" size="5" style="background-color:#3498DB"><b> CONDENSED MATTER PHYSICS @ IIT Mandi </b></font></p>
    </div>
<div id="mainnav">
		<div id="globalnav">
			<ul>
				<!--<P align="center"><FONT COLOR="white"><b>June 18th - 22nd, 2018<b></FONT></p>-->

			</ul>
<!--<p><font color="red"><marquee scrollamount=2><b>Date of the course is June 18-22, 2018. Last date of receiving application is June 10th, 2018 </b></marquee></font></p>
		</div>-->
		
	</div>
