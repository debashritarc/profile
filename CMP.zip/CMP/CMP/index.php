<?php 
include('header.php')
?>
<title>Condensed Matter Physics Lab</title>
	<?php
	include('sidebar.php')
	?>
		<?php
		include('slider.php')
		?>			



		
		<div id="maincontent">
				<h1>Activities and Interest</h1>
				<div >
					
						<p id="para1">
							<ul class="bullet">
								<li>Correlation driven metal insulator transitions, Charge (or Spin)-density wave and other instabilities in electron systems, phenomenology of High-Tc superconductors, heavy fermions and Kondo effect. </li>
								<li>Phenomenology and modeling of correlated systems. dichalcogenides, spinels and other frustrated systems, double perovskites. </li>
								<li>Oxide Hetero-Interfaces: nature of superconductivity, magnetism, Lifshitz transition, Majorana modes, disorder.  Topological effects in condensed matter. </li>
 
<li>Statistical mechanics and studies of correlated and frustrated models (e.g., the Hubbard and extended-Hubbard models, Falicov-Kimball model): Spinels, magnetic and orbital frustration, Kitaev model, excitons.</li> 
 
<li>Electron-phonon interaction, formation and stability of polarons. Electrons in a strong magnetic field.</li>
 
<li>Correlated, disordered Bosons: phase diagram, low-lying excitations and thermodynamics, competition between correlation and disorder.</li>
 
<li>Quantum phase transitions, d4 systems. </li>
 
<li>Statistical mechanics of quasicrystals, NP-complete problems in physics.</li>

</li>
							
							</ul>
						</p>
					
			</div>
					
			</div>

<br /><br /><br />
<!--<table width="100%"><tr><td><td align="center"><font size="2.5"><u>Sponsored & Organized by</u><br/><br/>
<center><img src="images/iitmandi_logo.png" /></center>
<b>Indian Institute of Technology Mandi </font></td></tr>
 
</table></p><br />-->

					
			</div>
		</div><br /><br /><br /><br /><br /><div id="globalnav">
	<ul>
	        <li><br /></li>
		
	</ul>
</div>
</div>
</body></html>
