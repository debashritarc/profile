<?php
include('header.php')
?>
<title>Research</title>
	<?php
	include('sidebar.php')
	?>
             <?php
             include('slider.php')
             ?>
			<div id="maincontent">
				<h1>News and Highlights</h1><br>
				<p>
				    
				1. <a href="research/research_CSYadav.pdf">Research Highlights</a> of <a href="http://iitmandi.ac.in/CMP/files/CSY%20webpage/CSY_homepage.php">Dr. C.S. Yadav</a><br>
				2. <a href="https://www.thehindu.com/sci-tech/science/iit-mandi-team-observes-zero-resistance-at-high-temperatures-in-gold-silver-nanostructures/article27476922.ece">IIT Mandi team observes zero resistance at high temperatures in Gold-Silver nanostructures-<b>The Hindu</b> </a> <br>
				3. <a href=" https://twitter.com/serbonline/status/1136556335145709569">Twitter by SERB</a> 
				
				</p>
				
			
<!--<h2><a href="research_activity.php" target="blank">Research Activity</a></h2><br>
<h2><a href="exp_fac.php" target="blank">Experimental Facility</a></h2>
				<!--<div >
					
						<p >
						<font size="2">
<table border="3" cellpadding="2" cellspacing="2" width="100%">
<tr align="center"><td colspan="3"  align="center" >Smart Micro-Grids for Autonomous Zero-Net Energy Buildings</td></tr>
<tr align="center"><td colspan="3">Room No. 207, Academic Building, IIT Mandi, Mandi Campus, December 14-15, 2014)</td></tr>
 <tr align="center"><td colspan="3">Course Program </td></tr>
    <tr align="center"><td colspan="3">14/12/2014, Sunday</td></tr>
<tr align="center"><td><b>Time</b></td><td><b>Text</b></td><td><b>ppt by</b></td></tr>
<tr><td>9:00-9:30 Hrs </td><td>Registration</td><td></td></tr> 
<tr><td>9:30- 10:30 Hrs</td><td>Inauguration</td><td>Prof. Ramesh Oruganti IIT Mandi</td></tr> 
<tr><td>10:30-11:00 Hrs </td><td>Inaugural Tea</td><td></td></tr> 
<tr><td>11:00-12:30 Hrs</td><td><a href="files/Fransisco_1.pdf">Smart Micro-Grids for Autonomous Zero-Net Energy Buildings-1</a></td><td>Dr. Francisco  G. Longatt, Loughborough University, UK</td></tr> 

<tr><td>12:30-13:30 Hrs</td><td><a href="files/Bharat_Singh.pdf">Emerging Trends in Electric Power Systems and Performance Analysis of Smart Micro-Grids</a></td><td>Dr. Bharat S. Rajpurohit,  IIT Mandi</td></tr> 
<tr><td>13:30-14:30 Hrs </td><td>Lunch</td><td></td></tr>
<tr><td>14:30-15:30 Hrs</td><td><a href="files/Fransisco_3.pdf">Smart Micro-Grids for Autonomous Zero-Net Energy Buildings-2</a></td><td>Dr. Francisco  G. Longatt, Loughborough University, UK</td></tr> 

<tr><td>15:30-16:00 Hrs</td><td>Tea</td><td></td></tr> 



  <tr><td>16:00-17:30 Hrs </td><td><a href="files/Naran_Pindoriya.pdf">Integration of Rooftop SPV in Power Distribution Network</a> </td><td>Dr. Naran M. Pindoriya, IIT Gandhinagar</td></tr> 
<tr><td>18:00- 21:30Hrs </td><td>Cultural Program & Workshop Dinner</td><td>Multipurpose Hall, Academic Building, IIT Mandi</td></tr> 
<tr align="center"><td colspan="3">15/12/2014, Monday</td></tr> 

<tr><td>09:30-11:00 Hrs</td><td><a href="files/S_N_Singh.pdf">Challenges in Smart Grid Implementation</a></td><td>Prof. S. N. Singh, IIT Kanpur</td></tr> 

<tr><td>11:00-11:15 Hrs</td><td>Tea</td><td></td></tr> 

<tr><td>11.15-12.45 Hrs</td><td><a href="files/Rohit_Bhakar.pdf">Innovations in DC Grid Technologies & Research Challenges in Energy Systems </td><td>Dr. Rohit Bhakar, University of Bath, UK</td></tr> 

<tr><td>12:45-13:15 Hrs</td><td>Concluding Session & Certificate Distribution</td><td></td></tr> 

<tr><td>13:15-14:15 Hrs </td><td>Lunch</td><td></td></tr>

<tr><td>14:15-20:30</td><td>Tea</td><td></td></tr> 

<tr><td>03:30-05:00 </td><td>Visit to Parashar/Rewalsar Lake</td><td></td></tr>


       </table></font>
    				</p><br /><br /><br /></p><br />
				</div>-->
			
			<br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
							</div><br /><br /><br /><br /><br /><div id="globalnav">
			<ul>
				
<li><br /></li>
		
			</ul>
		</div>
			
			
		
			

</div>

</body></html>
