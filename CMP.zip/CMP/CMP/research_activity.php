<?php
include('header.php');
?>
<div class="container" style="font-size: 120%" align="justify">
	<div class="row">
		<div class="faculty">
			<div class="column">
				<div class="col-md-12">
					<h4><b><center>Research Activity at CMP Group</center></b></h4><br><br>
														 <br />
														 
														 
					 <h1>Activities and Interest</h1>
				<div >
					
						<p id="para1">
							<ul class="bullet">
								<li>Correlation driven metal insulator transitions, Charge (or Spin)-density wave and other instabilities in electron systems, phenomenology of High-Tc superconductors, heavy fermions and Kondo effect. </li>
								<li>Phenomenology and modeling of correlated systems. dichalcogenides, spinels and other frustrated systems, double perovskites. </li>
								<li>Oxide Hetero-Interfaces: nature of superconductivity, magnetism, Lifshitz transition, Majorana modes, disorder.  Topological effects in condensed matter. </li>
 
<li>Statistical mechanics and studies of correlated and frustrated models (e.g., the Hubbard and extended-Hubbard models, Falicov-Kimball model): Spinels, magnetic and orbital frustration, Kitaev model, excitons.</li> 
 
<li>Electron-phonon interaction, formation and stability of polarons. Electrons in a strong magnetic field.</li>
 
<li>Correlated, disordered Bosons: phase diagram, low-lying excitations and thermodynamics, competition between correlation and disorder.</li>
 
<li>Quantum phase transitions, d4 systems. </li>
 
<li>Statistical mechanics of quasicrystals, NP-complete problems in physics.</li>

</li>
							
							</ul>
						</p>
					
			</div><br><br></br>
					<!--<div class="col-md-3"><center><img src="images/sophisticated_instruments/powerxray.jpg" width="120" /><br /><b>Make: </b>Rigaku Corporation<br />

<b>Model:</b> SmartLab 9kW rotating anode x-ray diffractometer </center></div>
					<div class="col-md-8"><p><h4>Powder X-ray Diffractometer</h4>The temperature dependent Powder X-ray diffractometer is built on 9 KW rotating anode x-ray generator with NaI Scintillation counter detection system. Copper anode is used as the target material with fine focus filament as the cathode. Low temperature down to 12K is achieved using closed cycle liquid Helium cryostat. This system has theta-theta goniometer arrangement which keeps the sample horizontal and stationary.

The Cross Beam optics technology used in this systems helps in easy changeover from Bragg-Brentano para focusing to high intensity parallel beam geometry and vice versa depending on the application. There is also small angle x-ray scattering unit attached to the system. The attachments for the future installations include high temperature, Grazing Incidence X-ray Diffraction (GIXRD), X-ray Reflectometry (XRR) units.</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/eds.png" width="180" /><br /><b>Make: </b>FEI company Of USA<br />

<b>Model:</b> FP 5022/22-Tecnai G2 20 S-TWIN</center></div>
					<div class="col-md-8"><p><h4>High Resolution Transmission Electron Microscope (TEM) � Energy Dispersive Spectroscopy (EDS)</h4>An electron microscope uses high energy electron beams for the illumination of samples, instead of light so that magnification to the tune of a million times (10,000,000 x) and subnanometer resolution can be achieved. Electron microscopes are essential tools for characterizing nanomaterials as they provide an array of information such as topography, morphology, composition and crystallographic information. In the nanoworld, 'believe what you see' and electron microscopes such as TEM provides realistic images of nanomaterials. Infact, one of the major reasons for emergence of the field of nanotechnology is the invention of modern microscopes including the electron microscopes that have very high magnification and resolution in the nanometer length scales. In TEM, high energy electron beam passes through a very thin sample and constructs a two dimensional image of the sample. High resolution TEM can achieve atomic resolution. TEM also can be coupled with EDAX for elemental identification. Crystalllographic information of samples can also be obtained using selective area electron diffraction in TEM. EDS can be used to study chemistry of the materials and to do elemental mapping.</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/nmr1.png" width="150" /><br /><b>Make: </b>Jeol India<br />

<b>Model:</b> JNM ECX -500 </center></div>
					<div class="col-md-8"><p><h4>Nuclear Magnetic Resonance Spectrometer - 500 MHz</h4>Information about the structure, conformation and dynamics of small and large molecules can be obtained in the solution and solid state using NMR Spectrometer. Apart from common nuclei's like --1H and 13C, we can also record NMR spectra for other active nuclei's such as 19 F, 11B, 15N, 2D, 127I, 207Pb, 7Li, 6Li, 199Hg, 103Rh, 31P, 111Cd etc. Due to recent advances in spectroscopic techniques two dimensional NMR spectroscopy has become powerful tool to derive unique structural information of small and large molecules, some of the most useful techniques include 1H-1H COSY (Correlation Spectroscopy), Double quantum filtered 13C-1H COSY, Carbon detected 13C-1H COSY, Proton detected 1H-13C COSY: HMQC (Heteronuclear Multiple Quantum Correlation), Proton detected, Long Range 1H-13C Heteronuclear correlation: HMBC (Heteronuclear Multiple Bond Coherence), DQF (Double Quantum Filtered)-COSY, 1-D TOCSY (Totally Correlated Spectroscopy), 2-D TOCSY, HMQC- TOCSY, ROESY.</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/cm1.png" width="180" /><br /><b>Make: </b>Nikon Corporation<br />

<b>Model:</b> DTGTTAL SrGHT (DS-Qi1MC) </center></div>
					<div class="col-md-8"><p><h4>Confocal Microscopy</h4>The wave nature of light and the associated diffraction not only undermine resolution of common light microscope but also impose difficulty of miniaturizing photonic devices such as fiber optic cable and couplers. In order for light based circuitry to be competitive with current electronic circuits and to overcome the speed limitations of electronics, this size compatibility is a central challenge. Some of these tasks could be carried out by molecular devices such as photonic wires, and molecular switches involving organic fluorophores, inorganic quantum dots, nanoparticles, nanocomposites. Further, the advancement of DNA nanotechnology, in recent years, combined with nanomaterial offers a great opportunity to improve the nanotechnology research, biomedical application and in living cells.</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/Femtosecond_Laser_System.jpg" width="180" /><br /><b>Make: </b>Company Spectra Physics
Made in USA<br />

<b>Model:</b>   8PTF-36F-1K-ACE S/N 807</center></div>
					<div class="col-md-8"><p><h4>Femtosecond Laser System</h4>
					Transient absorption (TA) spectroscopy encompasses a powerful set of techniques for probing and characterizing the electronic properties of molecules or materials. This technique is used to study ultrafast photophysical and photochemical processes by monitoring transient states (e.g., excited states, charged species). These states are accessed upon absorption of photons and essentially represent higher energy forms of the system, differing from the lowest energy ground state in the distribution of electrons and/or nuclear geometry. Our femtosecond TA setup consists of a Ti:Sapphire regenerative amplifier (Spitfire Ace, Spectra Physics) seeded by an oscillator (Mai Tai SP, Spectra Physics) as light source. The laser output from the amplifier having wavelength 800 nm, pulse width < 35 fs and energy 4 mJ per pulse is divided into two beams to generate pump and probe pulses. A white light continuum (WLC) probe in the visible wavelength range is obtained by sending a small fraction of 800 nm focused beam through sapphire crystal. Probe is splited into two beams and detected as sample and reference separately to eliminate low frequency laser noises. A mechanical chopper of rotational frequency 500 Hz is used to create the pump blocked and unblocked conditions for the detection. TA spectra is recorded by CCD arrays after dispersion using a grating spectrograph (Acton spectra Pro SP 2358).
					</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/SC-XRD.jpg" width="200" /><br /><b>Make: </b><br />

<b>Model:</b>   </center></div>
					<div class="col-md-8"><p><h4>Single Crystal X-ray Diffractometer</h4>
					The most common experimental method of obtaining a detailed structure of a molecule, that allows resolution of individual atoms, single crystal X-ray diffraction (SCXRD) is performed by analysing the pattern of X-rays diffracted by an ordered array of many identical molecules (single crystal). Many pure compounds, from small molecules to organometallic complexes, proteins, and polymers, solidify into crystals under the proper conditions. When solidifying into the crystalline state, these individual molecules typically adapt one of only a few possible 3D orientations. When a monochromatic X-ray beam is passed through a single crystal, the radiation interacts with the electrons in the atoms, resulting in scattering of the radiation to produce a unique image pattern. Multiple images are recorded, with an area X-ray detector, as the crystal is rotated in the X-ray beam. Computationally intensive analysis of a set images results in a solution for the 3D structure of the molecule.
					</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/HRMS.jpg" width="200" /><br /><b>Make: </b><br />

<b>Model:</b>   </center></div>
					<div class="col-md-8"><p><h4>High Resolution Mass Spectrometery With LC-MS</h4>
					This is a next generation high accuracy (sub-ppm with internal calibration), high resolution (40,000 resolving power) tandem mass spectrometer, and ion funnel optics for maximum sensitivity. It's high scan rate allows excellent the characterization of complex mixtures such as with untargeted metabolomics experiments. It is able to obtain high resolution MS/MS spectra at 50 Hz! It has a dynamic range of 4 orders of magnitude and comes equipped with CaptivesprayTM nanoelectropray, conventional flow ESI for maximum flexibility.

The system is attached with Thermo Fisher LC-MS which is use to identify, characterize and quantify unknown and known compounds within complex matrices, including drug metabolites, environmental toxins and food additives. Our systems enable you to streamline your workflow and obtain more information from every run, from high throughput sample screening to discovering trace levels of unknowns.
					</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/BET.JPG" width="200" /><br /><b>Make: </b><br />

<b>Model:</b>   </center></div>
					<div class="col-md-8"><p><h4>BET surface area</h4>
					The adsorption/desorption isotherms and pore volumes of the adsorbents were determined by nitrogen adsorption-desorption isotherms, measured at 77 K using Quanta chrome Autosorb 1C system. The samples were degassed at 200<sup>o</sup>C under vacuum before starting N2 adsorption. Surface area and pore volumes (or pore size distribution) were determined using the Brunauer-Emmet-Teller (BET) equation, Barret-Joyner-Halenda (BJH) and DFT methods respectively.<br>
					<h4>Unique Features OF BET </h4>
					<p>Automatically performed Temperature programmed techniques (TPR/TPD/TPO. Flow-based, pulse titration method for rapid determination of active surface area, degree of metal dispersion.Available vapor generator option with heated manifold for use with water and organic vapors. Available, integrated mass spectrometer option for identification of desorbed gases. High sensitivity, thermal conductivity detector (TCD) for TPR/TPD/TPO analysis and automatic physisorption and chemisorption by precise vacuum volumetric method for analysis of BET surface area, meso- and micropore size distribution, active surface area, degree of metal dispersion, heats of adsorption, etc.</p>
					</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/HPLC.JPG" width="200" /><br /><b>Make: </b><br />

<b>Model:</b>   </center></div>
					<div class="col-md-8"><p><h4>HPLC</h4>
					All chromatographic separations, including HPLC operate under the same basic principle; separation of a sample into its constituent parts because of the difference in the relative affinities of different molecules for the mobile phase and the stationary phase used in the separation.

					</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/Rheometer.JPG" width="200" /><br /><b>Make: </b><br />

<b>Model:</b>   </center></div>
					<div class="col-md-8"><p><h4>Rheology</h4>
				Rheology is the study of the flow of matter, primarily in a liquid state, but also as �soft solids� or solids under conditions in which they respond with plastic flow rather than deforming elastically in response to an applied force. It is a branch of physics which deals with the deformation and flow of materials,both solids and liquid.

					</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				
				<div class="col-md-12">
					<div class="col-md-3"><center><img src="images/sophisticated_instruments/Chemisorption.JPG" width="200" /><br /><b>Make: </b><br />

<b>Model:</b>   </center></div>
					<div class="col-md-8"><p><h4>Chemisorptionanalyser(BEL CAT2)</h4>
			Chemisorption is a kind ofadsorption which involves a chemical
reaction between the surface and the adsorbate. New chemical bonds
are generated at the adsorbant surface. Examples include macroscopic
phenomena that can be very obvious, likecorrosion, and subtler effects
associated withheterogeneous catalysis. The strong interaction
between theadsorbate and thesubstratesurface creates new types of
electronicbonds.

					</p></div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>-->
				
				<div class="col-md-6"><h4><b>Multiferroics, Magnetocalorics, Heusler Alloys</b></h4><img src="images/Multiferroics.png" <align="center" width="600" /></div><br><br>


					<div class="col-md-6"><h4><b>Superconductivity, Metal-Insulator transition, Topological Insulators</b></h4><img src="images/Superconductivity.png" width="600" /></div><br><br>

	<div class="col-md-6"><h4><b>Thermoelectrics, Energy materials</b></h4><img src="images/Thermoelectrics.png" <align="center" width="600" /></div><br><br>
	
	<div class="col-md-6"><h4><b>Nano Science, Optoelectronics, Functional devices</b></h4><img src="images/Nano.png" <align="center" width="600" /></div><br><br>
	
	<div class="col-md-6"><h4><b>Electronic band structural calculation </b></h4><img src="images/Electronic.png" <align="center" width="600" /></div><br><br><br>

					<div class="col-md-6"><h4><b>Electron-Electron Correlation, Spin phonon coupling</b></h4><img src="images/Electron.png" width="700" /></div><br>

			





