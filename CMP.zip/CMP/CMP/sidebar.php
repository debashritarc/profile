
   
		<div id="maincontent" class="threecol_btm">
			<div id="promo">
				<div class="promonav">
					<ul class="promo_usernav">
						<li><a href="index.php">Home</a></li>
						<!--<li><a href="scope.php">Objective of the course</a></li>
						<li><a href="TargetAud.php">Target Audience</a></li>
						<li><a href="ResourcePerson.php">Resource Persons</a></li>
						<li><a href="committees.php">Committees </a></li>
						<li><a href="Registration.php" class="pu_last">Registration</a></li>
						<li><a href="ImportantDates.php" class="pu_last">Important Dates</a></li>-->
						
						
					
                                <ul>
                                        <li><a href="members.php">Faculty</a></li>	
                                        <li><a href="students.php">Students</a></li>
                                        </li>
                                        </ul>
					
                                                <li><a href="research.php">Research</a></li>
                                                 <li><a href="news.php">News and Highlights</a></li>
						<!--<li><a href="files/brochure_femer_2018.pdf" target="_blank" class="pu_last">Course Brochure (PDF)</a></li>
						<li><a href="files/registration_form_femer_2018.pdf"target="_blank" class="pu_last">Registration Form (PDF)</a></li>
						<li><a href="AboutIITMandi.php" class="pu_last">About IIT Mandi</a></li>
						<li><a href="AboutMandiClimate.php" class="pu_last">About Mandi &amp; its Climate</a></li>
						<li><a href="tourist_places.php" class="pu_last">Nearby Tourist Places</a></li>
						<li><a href="ContactUs.php" class="pu_last">Contact Us</a></li>-->
					</ul>
                                        <br /><br /><br /><br /><br />
                                   
                            <!--<table bgcolor="#CCCCCC" width="100%"><tr><td><p style="padding-bottom: 0pt;">
					<strong>Dr. Himanshu Pathak</strong><br />
					<strong>Course Coordinator </strong> <br />
					<strong>School of Engineering </strong><br />
					<strong>Indian Institute of Technology Mandi</strong><br />
<strong>Kamand-175075, Mandi, Himachal Pradesh</strong><br />
<strong>Contact: +91-1905-267224(O)</strong><br />

<strong>Email: stciitmandi@gmail.com &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><br />
</table>-->


				</div>