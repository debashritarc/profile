	<div id="content">
		<div >
			<div>
				<div >
					<ul class="promo_usernav">
						
					</ul>
				</div>
				<div class="promocontent">
					<div class="tabs">
						<a class="current" href="#">1</a>
						<a class="" href="#">2</a>
						<a class="" href="#">3</a>
						<a class="" href="#">4</a>
						<a class="" href="#">5</a>
						<a class="" href="#">6</a>
						<!--<a class="" href="#">7</a>
						<a class="" href="#">8</a>
						<a class="" href="#">9</a>
						<a class="" href="#">10</a>
						<a class="" href="#">11</a>-->
					</div>
					<div class="slides">
						<div style="display: block;" class="one"><p>PPMS</p></div>
						<div class="two"><p>Raman Spectrometer </p></div>
						<div style="display: none;" class="three"><p>MPMS</p></div>
						<div style="display: none;" class="four"><p>X-Ray Diffractometer</p></div>
						<div style="display: none;" class="five"><p>Photo Emission Spectrometer</p></div>
						<div style="display: none;" class="six"><p>Arc Melting Furnace</p></div>
						<!--<div style="display: none;" class="seven"><p>Shikari Devi View</p></div>
						<div style="display: none;" class="eight"><p>Shikari Devi View</p></div>
						<div style="display: none;" class="nine"></div>
						<div style="display: none;" class="ten"></div>
						<div style="display: none;" class="eleven"><p>Kamand Campus View</p></div>-->
					</div>
				</div>
			</div>