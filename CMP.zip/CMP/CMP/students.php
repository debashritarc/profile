
				<?php
include('header.php')
?>
<title>CMP</title>
	<?php
	include('sidebar.php')
	?>
             <?php
             include('slider.php')
             ?>
            <style> td,th{ padding:7px;}</style>
<div class="container" style="font-size: 120%" align="justify">
	<div class="row">
		<div class="faculty">
			<div class="row"><br>
		
			<h1><font color="Red">Students:</font></h1>
			
	 	<p>
	 	  <table align="Center" border=3 width=100% >
			 <tr align="center">
	              <td>Arzena Khatun</td><td>Ankit Sihi<td>Bharat M</td>
			       
			 </tr>
		     <tr align="center">
			       <td> Birender Singh</td><td>Deep Kumar</td><td>Imran Ahmad</td>
			 </tr>
			 <tr align="center">
			        <td>Jaskirat Brar </td><td>Juhi Pandey</td><td>Mukaddar SK</td>
			  </tr>
			  <tr align="center">
			        <td>Nidhi Chamoli</td><td>Niraj Kumar Singh</td><td>Promita Dutta</td>
			  </tr>
			  <tr align="center">
			        <td>Priyamedha Sharma</td><td> Rajneesh Kashyap</td><td>Rohit Pathak</td>
			  </tr>
			  <tr align="center">
			        <td>Ruchika Mahajan</td><td>Shamin SK</td><td>Shivaprasad S Shastri</td>
			  </tr>
			  <tr align="Center">
			        <td>Somnath Acharya</td><td>Vivek Kumar</td><td>Yogesh Khatri</td>
			  </tr>
			  </table>
		 </p>
			
			
			
			
			
			<!--<p><table><tr><td>Arzena Khatun</td><td>Ankit Sihi</td><td>Bharat M</td><td>Birender Singh</td><td>Deepu Kumar</td><td>Imran Ahmed</td><td>Jaskirat Brar</td></tr>
			
			<tr><td>Juhi Pandey</td><td>Mukaddar SK</td><td>Nidhi Chamoli</td><td>Niraj Kumar Singh</td><td>Paromita Dutta</td><td>Priyamedha Sharma</td><td>Rajneesh Kashyap</td></tr>
			
			<tr><td>Rohit Pathak</td><td>Ruchika Mahajan</td><td>Shamim SK</td><td>Shivaprasad S Shastri</td><td>Somnath Acharya</td><td>Vivek Kumar</td><td>Yogesh Khatri</td></tr>
			</table></p-->
				
	<!--<p><table> class="center" border=1><tr><td colspan=4><font color=#1e90ff style="font-weight:bold">Members</font></td></tr><tr><td><img class="displayed" src="http://iitmandi.ac.in/Schools/SBS/faculty/ajay.jpg" /><br>Imran Ahamed<br>Ph.D. (2014 batch)<br><!--Phone: 01905-267154<br>EMail:ajay@iitmandi.ac.in<br><a href="files/Ajay Soni.pdf"> Curriculum Vitae </a></td>
	<td><!--<img class="displayed" src="http://iitmandi.ac.in/Schools/SBS/faculty/arti.jpg" /><br>Rohit Pathak <br>Ph.D. (2014 batch)<br><!--Phone: 01905-267042<br>EMail:arti@iitmandi.ac.in<br><a href="files/arti kashyap.pdf"> Curriculum Vitae </a></td></tr>
<tr><td><!--<img class="displayed" src="http://iitmandi.ac.in/Schools/SBS/faculty/bindu.jpg"  /><br>Rajneesh Kashyap<br>Ph.D. (2017 batch)<br><!--Phone: 01905-267060<br>EMail:bindu@iitmandi.ac.in<br><a href="files/bindu.pdf"> Curriculum Vitae </a></td>
<td><!--<img class="displayed" src="http://iitmandi.ac.in/Schools/SBS/faculty/shekhar.jpg" /><br>Ruchika Mahajan<br>Integrated Ph.D. (2015 batch)<br><!--Phone: 01905-267135<br>Email:sekhar@iitmandi.ac.in<br><a href="files/CSY webpage/CSY homepage.html"> Homepage </a><tr>
    <td><!--<img class="displayed" src="http://iitmandi.ac.in/Schools/SBS/faculty/kaustav.jpg" /><br>Yogesh Khatri <br>Integrated Ph.D. (2016 batch)<br><!--Phone: 01905-267043<br>EMail:kaustav@iitmandi.ac.in<br><a href="files/Arghya Tarafdar.pdf"> Curriculum Vitae </a></td>
    <td><img class="displayed" src="http://iitmandi.ac.in/Schools/SBS/faculty/pkumar.jpg" /><br>Dr. Pradeep Kumar<br>Assistant Professor<br>Phone: 01905-267137<br>EMail:pkumar@iitmandi.ac.in<br><a href="files/pkumar.pdf"> Curriculum Vitae </a></td></tr>
<tr><td><img class="displayed" src="http://se.iitmandi.ac.in/faculty/upload/pics/sudhir.jpg" width="40%"  /><br>Dr. Sudhir Kumar Pandey<br>Assistant Professor<br>Phone: 01905-267066<br>EMail:sudhir@iitmandi.ac.in <br><a href="files/Arghya Tarafdar.pdf"> Curriculum Vitae </a></td>
<td><img class="displayed" src="images/at.jpg" width="20%" /><br>Dr. Arghya Taraphder<br>Professor<br>Phone: 01905-267142<br>EMail:arghya@iitmandi.ac.in <br><a href="files/arghya_tarafdar.pdf"> Curriculum Vitae </a></tr></table></p>
					
				<!--<div class="col-md-1">
					<img src="http://iitmandi.ac.in/Schools/SBS/faculty/ajay.jpg" width="100" align="left" />Dr. Ajay Soni<br />Assistant Professor<br />Phone: 01905-267154 <br />EMail:ajay@iitmandi.ac.in <br />
<a href="files/Ajay Soni.pdf"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>
				
				<div class="col-md-1">
				<img src="http://iitmandi.ac.in/Schools/SBS/faculty/arti.jpg" width="100" align="left" />Dr. Arti Kashyap <br />Associate Professor <br />Phone: 01905-267042 <br />EMail:arti@iitmandi.ac.in <br />
<a href="files/arti kashyap.pdf"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>
				
				<div class="col-md-1">
					<img src="http://iitmandi.ac.in/Schools/SBS/faculty/bindu.jpg" width="100" align="left" />Dr. Bindu Radhamany <br />Associate Professor<br />Phone: 01905-267060<br />EMail:bindu@iitmandi.ac.in <br />
<a href="files/Arghya Tarafdar.pdf"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>
				
				
				<div class="col-md-1">
					<img src="http://iitmandi.ac.in/Schools/SBS/faculty/shekhar.jpg" width="100" align="left" />Dr. Chandra Shekhar Yadav <br />Assistant Professor<br />Phone: 01905-267135 <br />Phone: 01905-267135<br />
<!--<a href="files/CSY webpage/CSY homepage.html"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>
				
				
				<div class="col-md-1">
				<img src="http://iitmandi.ac.in/Schools/SBS/faculty/kaustav.jpg" width="100" align="left" />Dr. Kaustav Mukherjee <br />Assistant Professor<br />Phone: 01905-267043<br />EMail:kaustav@iitmandi.ac.in <br />
<a href="files/Arghya Tarafdar.pdf"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>
				
				<div class="col-md-1">
				<img src="http://iitmandi.ac.in/Schools/SBS/faculty/pkumar.jpg" width="100" align="left" />Dr. Pradeep Kumar <br />Assistant Professor<br />Phone: 01905-267137<br />EMail:pkumar@iitmandi.ac.in <br />
<a href="files/Arghya Tarafdar.pdf"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>
				
				<div class="col-md-1">
				<img src="http://se.iitmandi.ac.in/faculty/upload/pics/sudhir.jpg" width="100" align="left" />Dr. Sudhir Kumar Pandey <br />Assistant Professor<br />Phone: 01905-267066 <br />EMail:sudhir@iitmandi.ac.in <br />
<a href="files/Arghya Tarafdar.pdf"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>
				
				<div class="col-md-1">
					<img src="images/at.jpg" width="100" align="left" />Dr. Arghya Taraphder <br />Professor<br />Phone: 01905-267142 <br />EMail:arghya@iitmandi.ac.in <br />
<a href="files/arghya_tarafdar.pdf"> Curriculum Vitae </a>
				</div><br>
				<div>&nbsp;</div><br>-->
					
				
				
			
		
			

</div><br /><br /><div id="globalnav">
			<ul>
				
<li><br /></li>
		
			</ul>
		</div>
</body></html>
