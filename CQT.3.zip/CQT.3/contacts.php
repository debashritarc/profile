<?php
//include("db.php");
//include("dbremote.php");
?>
<?php
include 'header.php';
?>

<section class="contact-content-section">
  <div class="container-fluid">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <div class="text-dark " data-setbg="">
          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <div class="section-title">
                <h2>Contact</h2>
                <hr>
                <p>If you have any questions or inquiries, please feel free to contact:</p>
              </div>
              <div class="cs-text">
                <div class="ct-address">
                  <span>Resource Person:</span>
                  <p>Dr. C.S. Yadav
                    <br />Associate Professor
                  </p>
                </div>
                <ul>
                  <li>
                    <span>Phone:</span>
                    01905-267258
                  </li>
                  <li>
                    <span>Email:</span>
                    shekhar@iitmandi.ac.in
                  </li>
                </ul>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="cc-map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13566.590129527007!2d76.9959121!3d31.780098!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xe0c4d446cc9584ca!2sIIT-Mandi%20(North%20Campus)!5e0!3m2!1sen!2sin!4v1661249010973!5m2!1sen!2sin" height="580" style="border:0;" allowfullscreen=""></iframe>
          <div class="map-hover">
            <i class="fa fa-map-marker"></i>
            <div class="map-hover-inner">
              <h5>IIT Mandi North Campus</h5>
              <p>Mandi, HP</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
include 'footer.php';
?>