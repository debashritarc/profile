<?php ?>
<!-- Footer Section Begin -->
<footer class="footer-section">
   <div class="container">

      <div class="row">
         <div class="col-lg-12">
            <div class="footer-text">
               <div class="ft-logo">
                  <a href="#" class="footer-logo"><img src="img/newlogo.png" alt="" style="max-width:100px"></a>
               </div>

               <div class="copyright-text">
                  <p>
                     Copyright &copy;<script>
                        document.write(new Date().getFullYear());
                     </script> All rights reserved | Center for Quantum Technologies (CQT)
                  </p>
               </div>

            </div>
         </div>
      </div>
   </div>
</footer>
<!-- Footer Section End -->

<!-- Js Plugins -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.countdown.min.js"></script>
<script src="js/jquery.slicknav.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/main.js"></script>
</body>

</html>