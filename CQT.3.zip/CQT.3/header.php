<?php ?>
<!DOCTYPE html>
<html lang="zxx">

<head>
   <meta charset="UTF-8">
   <meta name="description" content="">
   <meta name="keywords" content="">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>Center for
      Quantum Technologies | IIT Mandi</title>

   <!-- Google Font -->
   <link href="https://fonts.googleapis.com/css?family=Work+Sans:400,500,600,700,800,900&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap" rel="stylesheet">


   <!-- Css Styles -->
   <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
   <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
   <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
   <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
   <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
   <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
   <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>


   <!-- Header Section Begin -->
   <header class="header-section">
      <div class="container">
         <div class="logo">
            <a href="index.php">
               <img src="img/iitlogonew.png" alt="" style="max-width:350px">
            </a>
         </div>
         <div class="nav-menu">
            <nav class="mainmenu mobile-menu">
               <ul>
                  <li class="active"><a href="index.php">Home</a></li>

                  <li><a href="javascript:void(0)">Research</a>
                     <ul class="dropdown">
                        <li><a href="quantum_optical_computing.php">Quantum Optical Computing</a></li>
                        <li><a href="quantum_communication.php">Quantum Communication</a></li>
                        <li><a href="quantum_cryptography.php">Quantum Cryptography</a></li>
                        <li><a href="quantum_optics.php">Quantum Optics</a></li>
                        <li><a href="quantum_education.php">Quantum Education</a></li>
                     </ul>
                  </li>
                  <li><a href="people.php">People</a></li>
                  <li><a href="publications.php">Publications</a></li>
                  <li><a href="contacts.php">Contact</a></li>
               </ul>
            </nav>
            <!-- <a href="#" class="primary-btn top-btn"><i class="fa fa-ticket"></i> Ticket</a> -->
         </div>
         <div id="mobile-menu-wrap"></div>
      </div>
   </header>