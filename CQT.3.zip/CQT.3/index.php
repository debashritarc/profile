<?php
//include("db.php");
//include("dbremote.php");
?>
<?php
include 'header.php';
?>



<!-- Header End -->

<!-- Hero Section Begin -->
<section class="hero-section set-bg" data-setbg="img/cqt-bg.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="hero-text">

          <h2>Center for <br /> Quantum Technologies (CQT)</h2>

        </div>
      </div>

    </div>
  </div>
</section>
<!-- Hero Section End -->



<!-- Home About Section Begin -->
<section class="home-about-section">
  <div class="container">
    <div class="row">

      <div class="col-lg-12">
        <div class="ha-text">
          <h2>About</h2>
          <p align="justify"> Welcome to the Quantum Technology Research Center at IIT Mandi, India. We are dedicated to advancing the field of quantum computing and educating future generations of Indian quantum computing scientists. Our center is focused on building a reliable and scalable optical vortex-based quantum computing platform, capable of solving specific problems without the need for algorithms.

            Our ultimate goal is to demonstrate that current research on building classic quantum computers does not fully harness the true potential of quantum phenomena for unsupervised operations. We aim to explore how multiple quantum phenomena can work together to instantly deliver deeper insights into any unknown data, thereby ending the obsession with speed-up via quantum computing.

            To achieve these goals, we have established a national laboratory with state-of-the-art facilities to test all hallmarks of optical quantum computing, including a quantum supremacy testing facility. We are also building a prototype construction facility for a quantum computer and cryptographic device. Our center is constantly working on developing and optimizing nanowire self-assembly as encoding of quantum algorithms for the optical vortex-based quantum computer.
          </p>


        </div>
      </div>
    </div>
  </div>
</section>
<!-- Home About Section End -->






<?php
include 'footer.php';
?>