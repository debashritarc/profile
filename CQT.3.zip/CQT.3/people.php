<?php
//include("db.php");
//include("dbremote.php");
?>
<?php
include 'header.php';
?>

<div class="container">
  <div class="row">
    <div class="col-lg-12">

      <h2>People</h2>
      <hr>


    </div>
  </div>

</div>

<!-- Speaker Section Begin -->
<section class="speaker-section spad">
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/directorprofile.png" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://faculty.iitmandi.ac.in/director/">
                    <h4>Prof. Laxmi Dhar Behera</h4>
                  </a>
                  <span>Director, IIT Mandi</span>
                </div>


              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/rpsingh.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://www.prl.res.in/~rpsingh/">
                    <h4>Rabindra Pratap Singh</h4>
                  </a>
                  </a>
                  <span>Quantum optics & Quantum communication, Lead, PRL, India</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/pati-ranjit-personnel.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://www.mtu.edu/physics/department/faculty/pati/">
                    <h4>Ranjit Pati</h4>
                  </a>
                  <span>Quantum theory of atomic structures, MTU, USA</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/Martin-Timms-2.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://www.researchgate.net/profile/Martin-Timm">
                    <h4>Martin Timms </h4>
                  </a>
                  <span>Engineering commercial portable quantum computer, UK</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/anirban.jpeg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://samurai.nims.go.jp/profiles/anirban_bandyopadhyay?locale=en">
                    <h4>Anirban Bandyopadhyay</h4>
                  </a>
                  <span>Neuromorphic computing, NIMS Japan, IIT Mandi</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/suman.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://samurai.nims.go.jp/profiles/anirban_bandyopadhyay?locale=en">
                    <h4>Suman Kalyan Pal </h4>
                  </a>
                  <span>Exciton spectroscopy, light-matter interaction, IIT Mandi</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/Shekhar.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://samurai.nims.go.jp/profiles/anirban_bandyopadhyay?locale=en">
                    <h4>C.S.Yadav (Shekhar)</h4>
                  </a>
                  <span>Low temperature Physics, Quantum Transport, IIT Mandi</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/pathak.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="hhttps://faculty.iitmandi.ac.in/~ppathak/">
                    <h4>Pradyumna Pathak </h4>
                  </a>
                  <span>Mechano-optics, optical cavity, IIT Mandi</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/Hari.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://faculty.iitmandi.ac.in/~hari/">
                    <h4>Hari Varma </h4>
                  </a>
                  <span>Atomic trap for light-matter interaction, IIT Mandi</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/pushpendra.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://samurai.nims.go.jp/profiles/singh_pushpendra?locale=en">
                    <h4>Pushpendra Singh </h4>
                  </a>
                  <span>Quantum electronics and optics, NIMS Japan</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>



      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/pathik.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://scholar.google.com/citations?user=e0MNW4oAAAAJ&hl=en">
                    <h4> Pathik Sahoo </h4>
                  </a>
                  <span>Organic nanowire synthesis, NIMS Japan</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>



      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/jhimli.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://www.linkedin.com/in/jhimli-sarkar-manna-53330125/">
                    <h4>Jhimli Sarkar </h4>
                  </a>
                  <span>Microfluid gel chip for cryptography, IIT Kharagpur</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>



      <div class="col-sm-6">
        <div class="speaker-item">
          <div class="row">
            <div class="col-lg-6">
              <div class="si-pic">
                <img src="img/Arunangshu-Debnath.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6">
              <div class="si-text">
                <div class="si-title">
                  <a href="https://desy-theory.cfel.de/team/research_scientists/dr_arunangshu_debnath/">
                    <h4>Arunagshu Debnath </h4>
                  </a>
                  <span>Quantum Algorithm, Germany</span>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

  </div>
</section>
<!-- Speaker Section End -->


<?php
include 'footer.php';
?>