<?php
//include("db.php");
//include("dbremote.php");
?>
<?php
include 'header.php';
?>


<section>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2>Publications</h2>
        <hr>
        <p>We have published numerous papers and articles in various scientific journals and conferences. Visit our Publications page to see a list of our recent publications.</p>


        <b>Papers:</b><br>
        A Biswas, A Banerji, N Lal, P Chandravanshi, R Kumar, and R P Singh, Quantum key distribution with multiphoton pulses: an advantage; Optics Continuum 1(1), 68-79 (2022)<br><br>
        V Raskatla, B P Singh, S Patil, V Kumar, R P Singh, Speckle-based deep learning approach for classification of orbital angular momentum modes, Journal of the Optical Society of America A 39, 759-765 (2022)<br><br>
        Chithrbhanu P, Nijil Lal, Ali Anwar, Salla Gangi Reddy, and R. P. Singh, Quantum information with even and odd states of orbital angular momentum of light, Physics Letters A 381, 1858-1865 (2017)<br><br>
        Vijay Kumar, Bruno Piccirillo, Salla Gangi Reddy, and R. P. Singh, Topological structures in vector speckle fields, Optics Letters 42(3), 466-469 (2017)<br><br>
        Zhang, Y., Liu, C., Cao, Y., Guo, Q., He, C., Wei, Y., ... &amp; Xiao, M. (2020). Chiral spin states in helical organic nanowires for topological qubits. Science Advances, 6(37), eaba0900.<br><br>
        Mair, A., Vaziri, A., Weihs, G., &amp; Zeilinger, A. (2001). Entanglement of the orbital angular momentum states of photons. Nature, 412(6844), 313-316<br><br>
        Yao, A. M., Padgett, M. J., &amp; Barnett, S. M. (2011). Optical angular momentum: challenges and prospects. Advances in Optics and Photonics, 3(2), 161-204<br><br>
        Sahoo, P.; Singh, P.; Manna, J.; Singh, R.P.; Hill, J.P.; Nakayama, T.; Ghosh, S.; Bandyopadhyay, A. A Third Angular Momentum of Photons. Symmetry 2023, 15, 158. https://doi.org/10.3390/sym15010158<br><br>
        Anirban Bandyopadhyay, Nanobrain: The making of an artificial brain from a time crystal:; 336 pages; Taylor &amp; Francis Inc. Imprint CRC Press Inc., 2020 Bosa Roca, United States; ISBN10 1439875499; ISBN13 9781439875490; https://doi.org/10.1201/9780429107771 <br><br>
        K. Saxena, P. Singh, J. Sarkar, P. Sahoo, S. Ghosh, S. D. Krishnananda, and A. Bandyopadhyay; Polyatomic time crystals of the brain neuron extracted microtubule are projected like a hologram meters away; Journal of Applied Physics 132, 194401 (2022); https://doi.org/10.1063/5.0130618 <br><br>
        S. Ghosh, D. Fujita &amp; A. Bandyopadhyay; An organic jelly made fractal logic gate with an infinite truth table; Scientific Reports 5, 11265 (2015)<br><br>

        <h2> Patents</h2><br>
        <li> Subrata Ghosh, Satyajit Sahu, Anirban Bandyopadhyay, Daisuke Fujita A supramolecular architecture creation by successive phase transitions and radiations, JP-2014-219958, </li>
        <li> Subrata Ghosh, Satyajit Sahu, Anirban Bandyopadhyay, Daisuke Fujita, Spiral capacitor-inductor device JP-2015-253320, 12/25/2015; </li>
        <li> A. Bandyopadhyay, S. Ghosh, D. Fujita; Universal Geometric-musical language for big data processing in an assembly of clocking resonators, JP-2017-150171, 8/2/2017: World patent received February 2019, WO 2019/026983; US Patent App. 16/635,900 (2020); </li>
        <li> A. Bandyopadhyay; S. Ghosh; D. Fujita; Human brain like intelligent decision-making machine; JP-2017-150173; 8/2/2017; World patent WO 2019/026984; US Patent App. 16/635,892 (2020); </li>
        <li> A. Bandyopadhyay; D. Fujita; Method for realizing quantum cloaking in electromagnetic device for remote imaging apparatus; JP 2021-172701; </li>
        <li> A. Bandyopadhyay; D. Fujita; Electromagnetic device, magnetic and electrical vortex synthesis device and magnetic and optical vortex synthesis device; JP 2021-172702; </li>
        <li> A. Bandyopadhyay; P. Sahoo, D. Fujita; Self-learning by information processing device and self-learning for information processing method Application：No. 2021-172703; </li>
        <li> P. Singh, P. Sahoo et al, Construction of self-operating algorithm free artificial human brain using organic gel; JP-18094-2023. </li>
        <li> P. Singh et al, Organic quantum computer that invents invariants in a rapidly changing big data; JP-18164-2023. </li>
        <li> An inductor made of arrayed capacitors (2010) JP-511630 Satyajit Sahu, Daisuke Fujita, Anirban Bandyopadhyay, US 9019685B2, 28th April 2015. European patent is EP2562776B1 https://patents.google.com/patent/EP2562776A1/de.</li>
        <p></p>
      </div>
    </div>
  </div>

</section>
<?php
include 'footer.php';
?>